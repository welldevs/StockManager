import logging
from sqlalchemy.orm import Session
from sqlalchemy import text, exc
from typing import List
from fastapi import HTTPException
from app.models.entry import EntryModel  # Agora estamos importando o modelo correto

# Configuração de Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def fetch_entry(db: Session, page: int, page_size: int) -> List[dict]:
    logger.info(f"Recebida solicitação para fetch_entry - Página: {page}, Tamanho da Página: {page_size}")
    
    # Verificação de parâmetros de entrada
    if page < 1:
        logger.warning("Número da página inválido (menor que 1)")
        raise HTTPException(status_code=400, detail="O número da página deve ser maior que 0")
    
    page_size = max(1, min(page_size, 100))  # Garante que page_size esteja entre 1 e 100

    query = text("""
        SELECT * FROM hub.sm_entradas_erp 
        OFFSET :offset ROWS FETCH NEXT :page_size ROWS ONLY
    """)

    try:
        results = db.execute(query, {"offset": (page - 1) * page_size, "page_size": page_size}).fetchall()
        logger.info(f"Consulta SQL executada com sucesso - Retornados {len(results)} registros")
    except exc.SQLAlchemyError as e:
        logger.error(f"Erro ao consultar o banco de dados: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao consultar o banco de dados: {str(e)}")
    
    if not results:
        logger.warning("Nenhum registro encontrado para os parâmetros informados.")
        return []

    # Converte a saída do banco para dicionário
    columns = [col.name for col in db.execute(query).keys()]  # Obtém os nomes das colunas
    data = [dict(zip(columns, row)) for row in results]

    logger.info("Retornando dados de entrada com sucesso.")
    return data
