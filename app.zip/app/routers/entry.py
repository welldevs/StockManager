from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List
from database.database import get_db
from app.models.entry import EntryModel
from services.entry_service import fetch_entry
from auth.jwt_bearer import JWTBearer  # 🔒 Proteção com JWT

router = APIRouter(
    prefix="/v1/entry",
    tags=["entry"],
    dependencies=[Depends(JWTBearer())]  # 🔐 Proteção nas rotas
)

@router.get("/", response_model=List[EntrySchema])
def get_entry(
    db: Session = Depends(get_db),
    page: int = Query(1, alias="page", ge=1),
    page_size: int = Query(10, alias="page_size", ge=1, le=100)
):
    entry_data = fetch_entry(db, page, page_size)
    
    # Converte a saída do banco de dados para Pydantic
    return entry_data if entry_data else []
